<!DOCTYPE html>
<html>
<head>
	<title>GIC Investment Results</title>
</head>
<body>
	<h1>GIC Investment Results</h1>
	<!--start building our table right in html and avoid having to echo it through php-->
	<table border='1'>
		<tr>
			<th>Year</th>
			<th>Start Balance</th>
			<th>Interest</th>
			<th>End Balance</th>
		</tr>

	<?php
		/*In this program we simply calculate the interest and year end balance on an investment made by some hypothetical client at a bank. We also respond to their end of maturity instructions.*/
		//here we get our POST variables
		$amount=$_POST['txtInvestment'];
		$rate=$_POST['selRate'];
		$term=$_POST['selTerm'];
		$instructions=$_POST['radMaturity'];
		//some additional variables to store the interest and balance
		$interest=0;
		$balance=0;

		for($x=1;$x<=$term;$x++)//here's our classic for loop that goes through each of the years of the investment
		{
			$interest=$amount*($rate/100.0);//calculate the interest by mulitplying it by the rate as a decimal
			$balance=$amount+$interest;//add the inteerst to the amount invested for our year end balance
			//print out each row showing the year, the year's starting amount, the inteerst made that year and the final end of year new balance
			//note how we echo the table row and table cell tags and info dynamically
			//also note how you can actually insert variables right into the string itself in php!
			echo "
					<tr>
						<th>$x</th>
						<th>$amount</th>
						<th>$interest</th>
						<th>$balance</th>
					</tr>
					";
					$amount=$balance;//reset the next years starting amount to be the current years end balance

		}//loop is done here so we echo the end of the table and other important info
		echo "</table>";
		echo "<br>Final Balance($):$balance";
		if($instructions=="1")
		{
			echo "<br>Your balance will be deposited into your holding account.";
		}
		else
		{
			echo "<br>Your balance will be reinvested again at $$rate % for $term years.";
		}

	?>
	
</body>
</html>